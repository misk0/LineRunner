import RPi.GPIO as GPIO   # Import the GPIO library.
import time               # Import time library

GPIO.setmode(GPIO.BOARD)

GPIO.setup(03, GPIO.OUT)   # Set pin3 as output

pwm=GPIO.PWM(03,50)

pwm.start(0)

GPIO.output(03,True)

pwm.ChangeDutyCycle(2.75)
time.sleep(3)
pwm.ChangeDutyCycle(7)
time.sleep(3)
pwm.ChangeDutyCycle(11.75)
time.sleep(3)
GPIO.output(03,False)
#def SetAngle(angle):
#    duty = angle/19+2.75
#    GPIO.output(03,True)
#    pwm.ChangeDutyCycle(duty)
#    time.sleep(5)
#    GPIO.output(03,False)
#    pwm.ChangeDutyCycle(0)

#SetAngle(180)

pwm.stop()

GPIO.cleanup()


    