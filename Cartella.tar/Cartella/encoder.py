#!/usr/bin/python
import RPi.GPIO as GPIO   # Import the GPIO library.
import time               # Import time library

GPIO.setmode(GPIO.BOARD)

pin = 7
GPIO.setup(pin, GPIO.IN)

i = 0

while i < (6400*5+1):
    GPIO.wait_for_edge(pin, GPIO.FALLING)
    i = i+1

GPIO.cleanup()
