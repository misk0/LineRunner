import RPi.GPIO as GPIO   # Import the GPIO library.
import time               # Import time library

GPIO.setmode(GPIO.BCM)

LINE = 15   #GPIO15 = pin10


print "Distance Measurement In Progress"

GPIO.setup(LINE, GPIO.IN)   # Set GPIO 15 LINE pin 10 to input mode.


i = 0

while i < 100:

    if GPIO.input(LINE)==0:
        print("nero")

    if GPIO.input(LINE)==1:
        print("bianco") 

    i = i + 1
    time.sleep(0.5)


GPIO.cleanup()