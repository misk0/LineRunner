#!/usr/bin/env python

import RPi.GPIO as GPIO
import SimpleMFRC522

reader = SimpleMFRC522.SimpleMFRC522()

try:
	id,text = reader.read()
	esa = hex(id)
	esa = esa[2:10]
	print("paragono lo UID con e5788628")
        if esa == "e5788628":
            print("trovato")

finally:
	GPIO.cleanup()


